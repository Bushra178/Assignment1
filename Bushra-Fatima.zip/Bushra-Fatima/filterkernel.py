#!/usr/bin/env python
# coding: utf-8

# In[15]:


from PIL import Image
from PIL import ImageFilter
import cv2
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# # APPLYING FILTER KERNEL

# # # Image Before Filter

# In[10]:


image = cv2.imread('C:/Users/Bushra Fatima/Documents/images/stone.jpg')
image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
fig, ax = plt.subplots(1, figsize=(12,8))
plt.imshow(image)


# # #Blur Effect

# In[11]:


kernel = np.ones((3, 3), np.float32) / 9
 
img = cv2.filter2D(image, -1, kernel)
fig, ax = plt.subplots(1, figsize=(12,8))
plt.imshow(img)


# # #  Sharpen Effect

# In[12]:


kernel = np.array([[0, -1, 0],
                   [-1, 5, -1],
                   [0, -1, 0]])
img = cv2.filter2D(image, -1, kernel)
fig, ax = plt.subplots(1, figsize=(12,8))
plt.imshow(img)


# # # Blur effect with built-in function

# In[24]:


image = cv2.imread('C:/Users/Bushra Fatima/Documents/images/stone.jpg')
image = cv2.blur(img, (5,5))
fig, ax = plt.subplots(1, figsize=(12,8))
plt.imshow(image)


# # # Sharp effect with built-in function

# In[21]:


image = cv2.imread('C:/Users/Bushra Fatima/Documents/images/stone.jpg')
fig, ax = plt.subplots(1, figsize=(12,8))
sharpened1 = imageObject.filter(ImageFilter.SHARPEN);
plt.imshow(sharpened1)


# # Comparison 
# In blurring effect we see more blurred image in python buit-in function. However in sharpening effect filter kernel was more effective and provided more sharpened and detailed image. 

# In[ ]:





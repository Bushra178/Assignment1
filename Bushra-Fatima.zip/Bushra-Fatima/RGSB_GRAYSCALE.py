#!/usr/bin/env python
# coding: utf-8

# In[29]:


import cv2
import numpy as np
from matplotlib import pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[18]:


img=plt.imread('C:/Users/Bushra Fatima/Documents/images/03.png')



f = plt.figure(figsize=(15, 15))
f.add_subplot(1, 2, 1)
plt.imshow(img, cmap = 'gray')
plt.title("RGB Image")

f.add_subplot(1, 2, 2)
imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
plt.imshow(imgGray, cmap='gray')
plt.title("Grayscale Image")


# In[17]:



img=plt.imread('C:/Users/Bushra Fatima/Documents/images/04.jpg')



f = plt.figure(figsize=(15, 15))
f.add_subplot(1, 2, 1)
plt.imshow(img, cmap = 'gray')
plt.title("RGB Image")

f.add_subplot(1, 2, 2)
imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
plt.imshow(imgGray, cmap='gray')
plt.title("Grayscale Image")


# In[16]:


img=plt.imread('C:/Users/Bushra Fatima/Documents/images/05.jpeg')



f = plt.figure(figsize=(15, 15))
f.add_subplot(1, 2, 1)
plt.imshow(img, cmap = 'gray')
plt.title("RGB Image")

f.add_subplot(1, 2, 2)
imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
plt.imshow(imgGray, cmap='gray')
plt.title("Grayscale Image")


# In[ ]:





# In[22]:


img=plt.imread('C:/Users/Bushra Fatima/Documents/images/06.jpeg')



f = plt.figure(figsize=(15, 15))
f.add_subplot(1, 2, 1)
plt.imshow(img, cmap = 'gray')
plt.title("RGB Image")

f.add_subplot(1, 2, 2)
imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
plt.imshow(imgGray, cmap='gray')
plt.title("Grayscale Image")


# In[23]:


img=plt.imread('C:/Users/Bushra Fatima/Documents/images/07.jpg')



f = plt.figure(figsize=(15, 15))
f.add_subplot(1, 2, 1)
plt.imshow(img, cmap = 'gray')
plt.title("RGB Image")

f.add_subplot(1, 2, 2)
imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
plt.imshow(imgGray, cmap='gray')
plt.title("Grayscale Image")


# In[ ]:





# In[26]:


img=plt.imread('C:/Users/Bushra Fatima/Documents/images/other.jpg')



f = plt.figure(figsize=(15, 15))
f.add_subplot(1, 2, 1)
plt.imshow(img, cmap = 'gray')
plt.title("RGB Image")

f.add_subplot(1, 2, 2)
imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
plt.imshow(imgGray, cmap='gray')
plt.title("Grayscale Image")


# In[27]:


img=plt.imread('C:/Users/Bushra Fatima/Documents/images/stone.jpg')



f = plt.figure(figsize=(15, 15))
f.add_subplot(1, 2, 1)
plt.imshow(img, cmap = 'gray')
plt.title("RGB Image")

f.add_subplot(1, 2, 2)
imgGray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
plt.imshow(imgGray, cmap='gray')
plt.title("Grayscale Image")


# In[ ]:





#!/usr/bin/env python
# coding: utf-8

# # Image 1 

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageOps
get_ipython().run_line_magic('matplotlib', 'inline')


# In[2]:


#image before equalization 

img=plt.imread('C:/Users/Bushra Fatima/Documents/images/stone.jpg')
plt.imshow(img)


# In[6]:


# Displaying histogram before equalization
plt.hist(img.ravel()) 


# In[9]:


# Applying image equalization

img_pil=Image.fromarray(np.uint8(img))
img_pil=ImageOps.equalize(img_pil)
plt.imshow(img_pil)


# In[11]:


# Displaying Equalized image
img2=np.asarray(img_pil)
plt.imshow(img2)


# In[12]:


#Histogram after image Equalization
plt.hist(img2.ravel()) 


# # image 2

# In[20]:


#image before equalization 

img=plt.imread('C:/Users/Bushra Fatima/Documents/images/04.jpg')
plt.imshow(img)


# In[21]:


# Displaying histogram before equalization
plt.hist(img.ravel()) 


# In[25]:


# Applying image equalization

img_pil=Image.fromarray(np.uint8(img))
img_pil=ImageOps.equalize(img_pil)
plt.imshow(img_pil)


# In[26]:


# Displaying Equalized image
img2=np.asarray(img_pil)
plt.imshow(img2)


# In[27]:


#Histogram after image Equalization
plt.hist(img2.ravel()) 


# # Image 3

# In[28]:


#image before equalization 

img=plt.imread('C:/Users/Bushra Fatima/Documents/images/06.jpeg')
plt.imshow(img)


# In[29]:


# Displaying histogram before equalization
plt.hist(img.ravel()) 


# In[30]:


# Applying image equalization

img_pil=Image.fromarray(np.uint8(img))
img_pil=ImageOps.equalize(img_pil)
plt.imshow(img_pil)


# In[31]:


# Displaying Equalized image
img2=np.asarray(img_pil)
plt.imshow(img2)


# In[34]:


#Histogram after image Equalization
plt.hist(img2.ravel()) 


# In[ ]:




